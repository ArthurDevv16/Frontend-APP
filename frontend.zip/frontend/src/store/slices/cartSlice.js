import { createSlice } from '@reduxjs/toolkit'
const slice = createSlice({
  name:'cart',
  initialState:{ items: [] },
  reducers:{
    add(state, action){ state.items.push(action.payload) },
    remove(state, action){ state.items = state.items.filter(i=>i.id!==action.payload) },
    clear(state){ state.items = [] }
  }
})
export const { add, remove, clear } = slice.actions
export default slice.reducer

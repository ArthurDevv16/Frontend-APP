import React from 'react'
export default function Profile(){
  return (
    <div>
      <h3>Perfil</h3>
      <form className="w-50">
        <div className="mb-2">
          <label>Nome</label>
          <input className="form-control" />
        </div>
        <div className="mb-2">
          <label>Senha</label>
          <input type="password" className="form-control" />
        </div>
      </form>
    </div>
  )
}

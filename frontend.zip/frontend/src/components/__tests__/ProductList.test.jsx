import { render, screen } from '@testing-library/react'
import ProductList from '../ProductList'
test('render products header', ()=>{ render(<ProductList />); expect(screen.getByText(/Produtos/i)).toBeInTheDocument() })

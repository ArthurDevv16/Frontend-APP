import React, {useEffect, useState, useRef} from 'react'
import io from 'socket.io-client'
import axios from 'axios'

export default function WeatherWidget(){
  const [weather,setWeather]=useState(null)
  const socketRef = useRef()
  useEffect(()=>{
    // initial fetch via backend proxy
    axios.get(import.meta.env.VITE_BACKEND_URL + '/api/weather?q=London').then(r=>setWeather(r.data)).catch(()=>{})
    // websocket subscribe for push updates
    socketRef.current = io(import.meta.env.VITE_BACKEND_URL)
    socketRef.current.emit('subscribe:weather', {})
    socketRef.current.on('weather:update', data => setWeather(data))
    return ()=> socketRef.current.disconnect()
  },[])
  if(!weather) return <div className="alert alert-info">Carregando temperatura...</div>
  return (
    <div className="card mb-3">
      <div className="card-body d-flex justify-content-between">
        <div>
          <h5>{weather.name} — {weather.main.temp}°C</h5>
          <div>{weather.weather && weather.weather[0].description}</div>
        </div>
        <div>
          <img alt="icon" src={`http://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`} />
        </div>
      </div>
    </div>
  )
}

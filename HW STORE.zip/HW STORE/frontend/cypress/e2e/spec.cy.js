describe('HW Store smoke', ()=> {
  it('loads home', ()=> {
    cy.visit('http://localhost:5173')
    cy.contains('HW Store')
  })
})

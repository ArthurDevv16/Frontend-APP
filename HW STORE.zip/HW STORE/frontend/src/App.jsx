import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import ProductList from './components/ProductList'
import Cart from './components/Cart'
import Profile from './components/Profile'
import Chat from './components/Chat'
import WeatherWidget from './components/WeatherWidget'

export default function App(){
  return (
    <div className="container py-3">
      <header className="d-flex justify-content-between align-items-center mb-3">
        <h2>HW Store</h2>
        <nav>
          <Link to="/" className="me-2">Início</Link>
          <Link to="/profile" className="me-2">Perfil</Link>
          <Link to="/cart" className="me-2">Carrinho</Link>
          <Link to="/chat">Chat</Link>
        </nav>
      </header>

      <WeatherWidget />

      <Routes>
        <Route path="/" element={<ProductList />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/chat" element={<Chat />} />
      </Routes>
    </div>
  )
}

import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { remove, clear } from '../store/slices/cartSlice'

export default function Cart(){
  const items = useSelector(s=>s.cart.items)
  const dispatch = useDispatch()
  const total = items.reduce((s,i)=>s + i.price,0)
  return (
    <div>
      <h3>Carrinho</h3>
      <ul className="list-group mb-3">
        {items.map(i=> <li key={i.id} className="list-group-item d-flex justify-content-between">{i.name} <button className="btn btn-sm btn-danger" onClick={()=>dispatch(remove(i.id))}>Remover</button></li>)}
      </ul>
      <p>Total: R$ {total.toFixed(2)}</p>
      <button className="btn btn-secondary" onClick={()=>dispatch(clear())}>Limpar</button>
    </div>
  )
}

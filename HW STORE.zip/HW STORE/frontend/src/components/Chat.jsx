import React, {useEffect, useState, useRef} from 'react'
import { io } from 'socket.io-client'

export default function Chat(){
  const [msgs,setMsgs]=useState([])
  const [text,setText]=useState('')
  const socketRef = useRef()

  useEffect(()=>{
    socketRef.current = io(import.meta.env.VITE_BACKEND_URL)
    socketRef.current.on('chat:message', msg => setMsgs(m => [...m, msg]))
    return ()=> socketRef.current.disconnect()
  },[])

  function send(){
    if(!text) return
    const payload = { user: 'Anon', text, at: Date.now() }
    socketRef.current.emit('chat:message', payload)
    setText('')
  }

  return (
    <div>
      <h3>Chat em tempo real</h3>
      <div className="border p-2 mb-2" style={{height:200, overflow:'auto'}}>
        {msgs.map((m,i)=> <div key={i}><strong>{m.user}:</strong> {m.text}</div>)}
      </div>
      <div className="input-group">
        <input className="form-control" value={text} onChange={e=>setText(e.target.value)} />
        <button className="btn btn-primary" onClick={send}>Enviar</button>
      </div>
    </div>
  )
}

import React, {useEffect, useState} from 'react'
import axios from 'axios'
import { useDispatch } from 'react-redux'
import { add } from '../store/slices/cartSlice'

export default function ProductList(){
  const [products,setProducts]=useState([])
  const dispatch = useDispatch()
  useEffect(()=>{ axios.get(import.meta.env.VITE_BACKEND_URL + '/api/products').then(r=>setProducts(r.data)).catch(()=>{}) },[])
  return (
    <div>
      <h3>Produtos</h3>
      <div className="row">
        {products.map(p=>(
          <div key={p._id} className="col-md-4">
            <div className="card mb-3">
              <div className="card-body">
                <h5>{p.name}</h5>
                <p>{p.description}</p>
                <p>R$ {p.price}</p>
                <button className="btn btn-primary" onClick={()=>dispatch(add({id:p._id,name:p.name,price:p.price}))}>Adicionar</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

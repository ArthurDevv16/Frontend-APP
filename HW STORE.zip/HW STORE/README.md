# HW Store — Fullstack (Frontend + Backend)

Projeto entregue pronto para deploy. Layout e estrutura base inspirada no PDF fornecido pelo usuário. Fonte: uploaded mockup. fileciteturn0file0

## O que está incluído
- Frontend: React + Vite, Redux Toolkit, Bootstrap, Jest, Cypress.
- Backend: Node.js + Express + Socket.IO, endpoint proxy para OpenWeatherMap, WebSocket chat & real-time temp push.
- Database: integração com MongoDB via Mongoose (use Mongo Atlas or seu cluster).
- Tests: unit (Jest) e e2e (Cypress).
- Scripts para rodar localmente e instruções de deploy para Vercel (frontend) e Render (backend).

## Estrutura
```
/frontend
/backend
README.md
```

## Como usar (local)
1. Preencha os arquivos `.env.example` em `/backend` e `/frontend` com suas chaves (OpenWeatherMap, MONGO_URI).
2. Rodar backend:
```bash
cd backend
npm install
npm run dev
```
3. Rodar frontend:
```bash
cd frontend
npm install
npm run dev
```
4. Executar testes:
- Frontend unit: `cd frontend && npm run test`
- Cypress: `cd frontend && npm run cypress:open`

## Deploy
- Suba o código no GitHub (crie repositório e push).
- Frontend: conectar o diretório `/frontend` ao Vercel (use `build: npm run build` e `output: dist`).
- Backend: conectar `/backend` no Render como Web Service (start: `npm start`).
- Crie um cluster MongoDB Atlas e configure `MONGO_URI` no Render.
- Configure `OPENWEATHER_API_KEY` no backend env.

--- 
Este pacote contém código de exemplo pronto para ser modificado. Boa sorte!

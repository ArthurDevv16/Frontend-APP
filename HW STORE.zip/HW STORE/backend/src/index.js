import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import dotenv from 'dotenv';
import axios from 'axios';
import mongoose from 'mongoose';

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const PORT = process.env.PORT || 4000;
const OW_KEY = process.env.OPENWEATHER_API_KEY || '';
const MONGO_URI = process.env.MONGO_URI || '';

if (MONGO_URI) {
  mongoose.connect(MONGO_URI).then(()=>console.log('Mongo connected')).catch(e=>console.error(e));
}

// Simple product schema (for example)
const productSchema = new mongoose.Schema({
  name: String, price: Number, description: String, image: String, stock: Number
});
const Product = mongoose.models.Product || mongoose.model('Product', productSchema);

// REST - products (seed simple if empty)
app.get('/api/products', async (req, res)=>{
  const count = await Product.countDocuments();
  if (count === 0) {
    await Product.create([
      { name: 'SSD 1TB', price: 499.99, description:'SSD NVMe 1TB', image:'', stock:10 },
      { name: 'GPU RTX 4070', price: 2499.00, description:'Placa de video', image:'', stock:3 },
    ]);
  }
  const products = await Product.find();
  res.json(products);
});

// Proxy weather endpoint (by lat,lon or city)
app.get('/api/weather', async (req,res)=>{
  try{
    const { lat, lon, q } = req.query;
    let url;
    if (q) url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(q)}&appid=${OW_KEY}&units=metric`;
    else url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${OW_KEY}&units=metric`;
    const r = await axios.get(url);
    res.json(r.data);
  }catch(e){
    console.error(e.message);
    res.status(500).json({error:'weather fetch error'});
  }
});

// WebSocket chat + periodic weather push
io.on('connection', (socket) => {
  console.log('client connected', socket.id);
  socket.on('chat:message', (msg) => {
    io.emit('chat:message', msg);
  });
  socket.on('subscribe:weather', ({lat,lon,q})=>{
    socket.join('weatherRoom');
  });
});

// periodic weather broadcast every 30s (if key provided)
if (OW_KEY) {
  setInterval(async ()=>{
    try{
      const r = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=London&appid=${OW_KEY}&units=metric`);
      io.to('weatherRoom').emit('weather:update', r.data);
    }catch(e){
      // ignore
    }
  }, 30000);
}

server.listen(PORT, ()=>console.log('Server running on', PORT));
